# frozen_string_literal: true

module Rlt
  VERSION = '0.1.0'.freeze
end
